# Maginat: original code

This folder contains the original scripts, configuration and small programs written for Maginat
(installer, USB tool, persistence, welcome screen, tray icons for volume, Bluetooth and battery,
boot menu and ISO build scripts).

- `build/`: scripts used to build the ISO from the Linux From Scratch system.
- `system/`: files that are copied into the system (same layout as the installed system).

Third-party software (kernel, packages, firmware, patches) is not included here: it is in
`maginat-0.1-sources.tar` on the release page. See the main README for details.
Unless a file says otherwise, the original code is under GPL-2.0-or-later.
